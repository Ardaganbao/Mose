﻿[CmdletBinding()]
param (
    [Parameter(HelpMessage = 'Veeam Backup & Replication server; if the module is missing locally, this is also used as the remote execution host.')]
    [string]$Server = 'localhost',

    [Parameter(HelpMessage = 'Path where the Markdown report is saved on the computer running this script.')]
    [string]$OutputPath = 'C:\temp\veeam_temp.mq',

    [Parameter(HelpMessage = 'Do not open the completed report in Notepad.')]
    [switch]$NoOpen,

    [Parameter(HelpMessage = 'Run report generation on the Veeam server over PowerShell Remoting.')]
    [switch]$RunOnVbrServer,

    [Parameter(HelpMessage = 'Optional credential for PowerShell Remoting to the Veeam server.')]
    [System.Management.Automation.PSCredential]$RemotingCredential,

    [Parameter(HelpMessage = 'Veeam account for connecting to the Veeam server through the Veeam console installed on this computer.')]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter(HelpMessage = 'Only the SureBackup verification section (used by VeeamRestReport.ps1, whose REST API does not give SureBackup).')]
    [switch]$SureBackupOnly,

    # Set for the PowerShell 7 relaunch, whose output comes back as text: the first process writes the version for Report.ps1.
    [Parameter(DontShow)]
    [switch]$NoInventory
)

$ErrorActionPreference = 'Stop'
$veeamModuleName = 'Veeam.Backup.PowerShell'

# The Veeam PowerShell module on this computer: loaded, findable, or where the Veeam console installs it.
function Test-VeeamModuleHere {
    if ((Get-Command Connect-VBRServer -ErrorAction SilentlyContinue) -or (Get-Module -ListAvailable -Name $veeamModuleName -ErrorAction SilentlyContinue)) {
        return $true
    }
    $core = Get-ItemProperty -Path 'HKLM:\Software\Veeam\Veeam Backup and Replication\' -Name 'CorePath' -ErrorAction SilentlyContinue
    $manifests = @(Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1')
    if ($core -and $core.CorePath) {
        $manifests += Join-Path $core.CorePath 'Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1'
    }
    return [bool]@($manifests | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }).Count
}

# True when $Name is this computer: localhost, its name, its full DNS name or one of its addresses.
function Test-ThisComputer {
    param(
        [string]$Name
    )

    # A full DNS name can end with a dot (server.example.local.).
    $Name = $Name.Trim()
    if ($Name -ne '.') {
        $Name = $Name.TrimEnd('.')
    }
    $network = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()
    $names = @('localhost', '.', $env:COMPUTERNAME, $network.HostName)
    if ($network.DomainName) {
        $names += "$($network.HostName).$($network.DomainName)"
    }
    if ($Name -in $names) {
        return $true
    }
    $address = $null
    if ([System.Net.IPAddress]::TryParse($Name, [ref]$address)) {
        if ([System.Net.IPAddress]::IsLoopback($address)) {
            return $true
        }
        $addresses = @([System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
            ForEach-Object { $_.GetIPProperties().UnicastAddresses } | ForEach-Object { $_.Address.ToString() })
        return $address.ToString() -in $addresses
    }
    return $false
}
# A Veeam server named as this computer is the one this report runs on: no PowerShell remoting, and
# connected to as localhost.
$serverIsThisComputer = Test-ThisComputer $Server
# Like the other modules' progress bars. Run remotely, the Veeam server's bar shows here too.
$progressServer = if ($Server -in @('localhost', '.')) { $env:COMPUTERNAME } else { $Server }
$progressActivity = "Veeam report: $progressServer"

function Write-VeeamReportProgress {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Status,
        [Parameter(Mandatory = $true)]
        [int]$PercentComplete
    )

    $percent = [math]::Max(0, [math]::Min(100, $PercentComplete))
    Write-Progress -Id 10 -Activity $progressActivity -Status $Status -PercentComplete $percent
}

# For the report's Software table (Report.ps1). Not with -SureBackupOnly: its caller
# writes the version itself.
function Write-VeeamInventory {
    if (-not $SureBackupOnly -and -not $NoInventory) {
        [pscustomobject]@{ MoseInventory = 'Software'; Name = 'Veeam'; Version = "$veeamVersion"; Purpose = 'Backup and restore'; Server = $progressServer }
    }
}

Write-VeeamReportProgress -Status 'Starting report' -PercentComplete 0

# With the Veeam console installed here, its module connects to the server itself; without it, the
# report runs on the Veeam server over PowerShell remoting, unless that is this computer.
if (-not $serverIsThisComputer -and ($RunOnVbrServer -or -not (Test-VeeamModuleHere))) {
    if (-not (Test-Path -LiteralPath $PSCommandPath -PathType Leaf)) {
        throw 'Remote execution requires running this from the saved VeeamReport.ps1 file.'
    }

    $scriptContent = [System.IO.File]::ReadAllText($PSCommandPath)
    # This script is copied to a file on the Veeam server and runs there as a saved script, so it
    # can start itself again in PowerShell 7 when the Veeam module needs it (Veeam 13); the file is
    # removed after. What it writes comes back here: its report, the Veeam version, its messages.
    $remoteCommand = {
        param([string]$Source, [bool]$SureBackupOnly)
        $path = Join-Path ([System.IO.Path]::GetTempPath()) ("MOSE-VeeamReport-{0}.ps1" -f [guid]::NewGuid().ToString('N'))
        [System.IO.File]::WriteAllText($path, $Source, (New-Object System.Text.UTF8Encoding $true))
        try {
            # Unless a policy of the server forbids it, this file may run whatever the execution policy.
            try {
                Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction Stop
            }
            catch {
            }
            & $path -Server 'localhost' -OutputPath '' -NoOpen -SureBackupOnly:$SureBackupOnly
        }
        finally {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        }
    }
    $sessionParameters = @{ ComputerName = $Server; ErrorAction = 'Stop' }
    if ($null -ne $RemotingCredential) {
        $sessionParameters.Credential = $RemotingCredential
    }

    Write-VeeamReportProgress -Status "Connecting to '$Server' over PowerShell remoting" -PercentComplete 0
    $session = $null
    try {
        try {
            $session = New-PSSession @sessionParameters
        }
        catch {
            $failure = $_.Exception
            # WinRM reached the server, which refused the login. The error ID does not depend on the Windows language.
            $accessDenied = $_.FullyQualifiedErrorId -like 'AccessDenied*' -or
                ($failure.PSObject.Properties['ErrorCode'] -and $failure.ErrorCode -eq 5)
            $hint = ''
            $address = $null
            if ($accessDenied) {
                $account = if ($RemotingCredential) { $RemotingCredential.UserName } else { "$env:USERDOMAIN\$env:USERNAME" }
                $hint = " The server refused the login of $($account): on the Veeam server, it must be an administrator, or a member of its Remote Management Users group (Computer Management > Local Users and Groups > Groups), with a Veeam role; written DOMAIN\user, or SERVER\user for an account of the server itself. A local account other than the built-in Administrator also needs LocalAccountTokenFilterPolicy = 1 on the server."
            }
            elseif ([System.Net.IPAddress]::TryParse($Server, [ref]$address)) {
                $hint = " An IP address must also be in this computer's TrustedHosts and needs a login (-RemotingCredential): Report.ps1 offers to set both, or use the server's name."
            }
            # Report.ps1 reads RemotingAccessDenied to offer another login.
            $exception = [System.Exception]::new("Could not run the Veeam report remotely on '$Server'. Verify PowerShell Remoting/WinRM is enabled and your account can access the Veeam server.$hint $($failure.Message)", $failure)
            $exception.Data['RemotingAccessDenied'] = [bool]$accessDenied
            throw $exception
        }
        Write-VeeamReportProgress -Status "Running the report on '$Server'" -PercentComplete 5
        $remoteOutput = Invoke-Command -Session $session -ScriptBlock $remoteCommand -ArgumentList $scriptContent, ([bool]$SureBackupOnly) -ErrorAction Stop
    }
    finally {
        if ($session) {
            Remove-PSSession -Session $session -ErrorAction SilentlyContinue
        }
        Write-Progress -Id 10 -Activity $progressActivity -Completed
    }

    $Body = ($remoteOutput | Where-Object { $_ -is [string] } | Select-Object -Last 1)
    if ([string]::IsNullOrWhiteSpace([string]$Body)) {
        throw "Remote execution on '$Server' did not return a report."
    }
    # The Veeam version, as the Veeam server wrote it.
    $remoteOutput | Where-Object { $_ -isnot [string] -and $_.PSObject.Properties['MoseInventory'] }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) {
        $outputDirectory = Split-Path -Path $OutputPath -Parent
        if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path -LiteralPath $outputDirectory)) {
            New-Item -Path $outputDirectory -ItemType Directory -Force -ErrorAction Stop | Out-Null
        }
        $Body | Out-File -LiteralPath $OutputPath -Encoding UTF8 -ErrorAction Stop
        if (-not $NoOpen) {
            Start-Process -FilePath 'notepad.exe' -ArgumentList "`"$OutputPath`"" -ErrorAction Stop
        }
    }
    $Body
    return
}

$corePath = Get-ItemProperty -Path "HKLM:\Software\Veeam\Veeam Backup and Replication\" -Name "CorePath" -ErrorAction SilentlyContinue
$availableModule = Get-Module -ListAvailable -Name $veeamModuleName -ErrorAction SilentlyContinue |
    Sort-Object -Property PowerShellVersion -Descending |
    Select-Object -First 1
$moduleManifestCandidates = @()
if ($null -ne $availableModule -and -not [string]::IsNullOrWhiteSpace([string]$availableModule.Path)) {
    $moduleManifestCandidates += $availableModule.Path
}
if ($corePath -and -not [string]::IsNullOrWhiteSpace([string]$corePath.CorePath)) {
    $moduleManifestCandidates += Join-Path $corePath.CorePath 'Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1'
}
$moduleManifestCandidates += Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\Console\Veeam.Backup.PowerShell\Veeam.Backup.PowerShell.psd1'

$requiredPowerShellVersion = $null
$veeamModulePath = $null
$veeamVersion = $null
foreach ($manifestPath in $moduleManifestCandidates | Select-Object -Unique) {
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        continue
    }

    $moduleManifest = Import-PowerShellDataFile -LiteralPath $manifestPath -ErrorAction Stop
    if ($moduleManifest.ModuleVersion) {
        $veeamVersion = [string]$moduleManifest.ModuleVersion
    }
    if ($moduleManifest.RootModule -or $moduleManifest.ModuleToProcess) {
        $veeamModulePath = $manifestPath
    }
    if ($moduleManifest.PowerShellVersion) {
        $requiredPowerShellVersion = [version]$moduleManifest.PowerShellVersion
        break
    }
}
if ($null -eq $availableModule -and $veeamModulePath) {
    $availableModule = [pscustomobject]@{
        Path = $veeamModulePath
        Version = $veeamVersion
        PowerShellVersion = $requiredPowerShellVersion
    }
}
if ($null -ne $availableModule -and $availableModule.Version) {
    $veeamVersion = [string]$availableModule.Version
}
if ($null -ne $requiredPowerShellVersion -and
    $PSVersionTable.PSVersion -lt $requiredPowerShellVersion) {
    $pwshCommand = Get-Command -Name 'pwsh.exe' -All -ErrorAction SilentlyContinue
    $compatiblePwshPath = $null

    foreach ($candidate in @($pwshCommand | ForEach-Object { $_.Source }) + @(
        (Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe')
    ) | Select-Object -Unique) {
        if ([string]::IsNullOrWhiteSpace([string]$candidate) -or
            -not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            continue
        }

        $candidateVersionText = & $candidate -NoProfile -Command '$PSVersionTable.PSVersion.ToString()' 2>$null
        $candidateVersion = $null
        if ([version]::TryParse([string]$candidateVersionText, [ref]$candidateVersion) -and
            $candidateVersion -ge $requiredPowerShellVersion) {
            $compatiblePwshPath = $candidate
            break
        }
    }

    if ([string]::IsNullOrWhiteSpace($compatiblePwshPath)) {
        throw "The installed Veeam PowerShell module requires PowerShell $requiredPowerShellVersion or later, but this script is running under PowerShell $($PSVersionTable.PSVersion). Install a compatible PowerShell 7 runtime and run this script with pwsh.exe."
    }
    if ([string]::IsNullOrWhiteSpace($PSCommandPath)) {
        throw "The installed Veeam PowerShell module requires PowerShell $requiredPowerShellVersion or later. This report was invoked from an in-memory script block, so it cannot relaunch itself; run VeeamReport.ps1 from a saved file with pwsh.exe."
    }

    $credentialFile = $null
    # The report comes back in a file: what PowerShell 7 writes to its console (its messages and
    # warnings) comes back as text, shown here rather than taken for the report.
    $childOutputPath = $OutputPath
    $ownOutputFile = [string]::IsNullOrWhiteSpace($OutputPath)
    if ($ownOutputFile) {
        $childOutputPath = Join-Path ([System.IO.Path]::GetTempPath()) ("VeeamReport_{0}.md" -f [guid]::NewGuid())
    }
    try {
        $quotePowerShellLiteral = {
            param([string]$Value)
            "'" + $Value.Replace("'", "''") + "'"
        }
        $commandParts = @(
            '&'
            (& $quotePowerShellLiteral $PSCommandPath)
            '-Server'
            (& $quotePowerShellLiteral $Server)
            '-OutputPath'
            (& $quotePowerShellLiteral $childOutputPath)
        )
        if ($NoOpen -or $ownOutputFile) {
            $commandParts += '-NoOpen'
        }
        if ($RunOnVbrServer) {
            $commandParts += '-RunOnVbrServer'
        }
        if ($SureBackupOnly) {
            $commandParts += '-SureBackupOnly'
        }
        Write-VeeamInventory
        $commandParts += '-NoInventory'
        # The logins go through a file only this Windows user can read (Export-Clixml), removed below.
        $credentials = @{}
        if ($null -ne $RemotingCredential) {
            $credentials.RemotingCredential = $RemotingCredential
        }
        if ($null -ne $Credential) {
            $credentials.Credential = $Credential
        }
        if ($credentials.Count -gt 0) {
            $credentialFile = Join-Path ([System.IO.Path]::GetTempPath()) ("VeeamReportCredential_{0}.xml" -f [guid]::NewGuid())
            $credentials | Export-Clixml -LiteralPath $credentialFile -ErrorAction Stop
            foreach ($name in $credentials.Keys) {
                $commandParts += "-$name"
                $commandParts += "`$veeamReportCredentials['$name']"
            }
        }

        # Its report is read from the file, so its output is dropped; its error, if any, is read from a
        # file too (with -EncodedCommand, its error output is PowerShell's own XML).
        $childErrorPath = "$childOutputPath.error"
        $childCommand = 'try { ' + ($commandParts -join ' ') + ' | Out-Null } catch { Set-Content -LiteralPath ' +
            (& $quotePowerShellLiteral $childErrorPath) + ' -Value $_.Exception.Message -Encoding UTF8; exit 1 }'
        if ($credentialFile) {
            $childCommand = '$veeamReportCredentials = Import-Clixml -LiteralPath ' +
                (& $quotePowerShellLiteral $credentialFile) + '; ' + $childCommand
        }
        $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($childCommand))
        $childErrors = New-Object System.Collections.Generic.List[string]
        # With Stop, Windows PowerShell would stop at the first line PowerShell 7 writes to its error output.
        $previousPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            & $compatiblePwshPath -NoProfile -ExecutionPolicy Bypass -EncodedCommand $encodedCommand 2>&1 | ForEach-Object {
                if ($_ -is [System.Management.Automation.ErrorRecord]) {
                    $childErrors.Add("$_")
                }
                else {
                    Write-Host "$_"
                }
            }
            $exitCode = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $previousPreference
        }
        if ($exitCode -ne 0) {
            $message = if (Test-Path -LiteralPath $childErrorPath) { "$(Get-Content -LiteralPath $childErrorPath -Raw -Encoding UTF8)".Trim() } else { $childErrors -join ' ' }
            throw "PowerShell $requiredPowerShellVersion exited with code $exitCode while running the Veeam report: $message"
        }
        if (-not (Test-Path -LiteralPath $childOutputPath -PathType Leaf)) {
            throw "PowerShell $requiredPowerShellVersion ran the Veeam report but wrote no report."
        }
        Get-Content -LiteralPath $childOutputPath -Raw -Encoding UTF8
    }
    finally {
        if ($credentialFile -and (Test-Path -LiteralPath $credentialFile)) {
            Remove-Item -LiteralPath $credentialFile -Force -ErrorAction Stop
        }
        if ($ownOutputFile) {
            Remove-Item -LiteralPath $childOutputPath -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -LiteralPath "$childOutputPath.error" -Force -ErrorAction SilentlyContinue
    }
    return
}

$depDLLPath = $null
if ($corePath -and -not [string]::IsNullOrWhiteSpace([string]$corePath.CorePath)) {
    $depDLLPath = Join-Path -Path $corePath.CorePath -ChildPath "Packages\VeeamDeploymentDLL.dll" -Resolve -ErrorAction SilentlyContinue
}
if ($depDLLPath) {
    $file = Get-Item -LiteralPath $depDLLPath -ErrorAction Stop
    if ($file.VersionInfo.ProductMajorPart -ge 10) {
        # Not found by name when the console's folder is not in PSModulePath: imported by its path below.
        Import-Module $veeamModuleName -ErrorAction SilentlyContinue
    }
    
}
if (-not (Get-Command Connect-VBRServer -ErrorAction SilentlyContinue)) {
    if ($availableModule) {
        Import-Module $availableModule.Path -ErrorAction Stop
    }
}
# Veeam 9 and 10 have a snap-in instead of a module; PowerShell 7 has no snap-ins at all.
if (-not (Get-Command Connect-VBRServer -ErrorAction SilentlyContinue) -and (Get-Command Get-PSSnapin -ErrorAction SilentlyContinue)) {
    $registeredSnapin = Get-PSSnapin -Registered -Name 'VeeamPSSnapin' -ErrorAction SilentlyContinue
    if ($registeredSnapin) {
        Add-PSSnapin VeeamPSSnapin -ErrorAction Stop
    }
}
if (Get-Command Connect-VBRServer -ErrorAction SilentlyContinue) {
    Write-Verbose "Connect-VBRServer is available"
}
else {
    throw "The Veeam PowerShell commands are not on $env:COMPUTERNAME. Run this on the Veeam backup server, or give the Veeam server with -Server to run the report there over PowerShell remoting, or install the Veeam Backup & Replication Console here."
}
$ErrorActionPreference = 'Stop'
 

## Connect-VBRServer -Server $server -User $user -Password $pass
$script:VbrConnected = $false
Write-VeeamReportProgress -Status "Connecting to Veeam server '$Server'" -PercentComplete 0
try {
    try {
        $connectParameters = @{ Server = $Server; ErrorAction = 'Stop' }
        if ($serverIsThisComputer) {
            $connectParameters.Server = 'localhost'
            # Veeam 13 checks the server's certificate and, with no one here to accept it, refuses it.
            # A connection to this computer does not leave it, so nothing can stand in between.
            if ((Get-Command Connect-VBRServer).Parameters.ContainsKey('ForceAcceptTlsCertificate')) {
                $connectParameters.ForceAcceptTlsCertificate = $true
            }
        }
        if ($null -ne $Credential) {
            $connectParameters.Credential = $Credential
        }
        Connect-VBRServer @connectParameters | Out-Null
        $script:VbrConnected = $true
    }
    catch {
        $connectionError = $_
        $moduleVersion = if ($availableModule) { $availableModule.Version } else { 'unknown' }
        $diagnostics = @(
            "Target: $Server$(if ($serverIsThisComputer -and $Server -notin @('localhost', '.')) { ' (this computer, connected to as localhost)' })"
            "PowerShell: $($PSVersionTable.PSVersion)"
            "Veeam PowerShell module: $moduleVersion"
        )

        if ($serverIsThisComputer) {
            $backupService = Get-Service -Name 'VeeamBackupSvc' -ErrorAction SilentlyContinue
            if ($backupService) {
                $diagnostics += "Veeam Backup Service: $($backupService.Status)"
            }
            else {
                $diagnostics += 'Veeam Backup Service: not found on this computer'
            }
        }

        $errorId = if ($connectionError.FullyQualifiedErrorId) { $connectionError.FullyQualifiedErrorId } else { 'unavailable' }
        throw "Failed to connect to Veeam server '$Server'. Check that the Veeam Backup & Replication service is running, this account has permission to connect, and the installed console/module is compatible with the server version.`n$($diagnostics -join [Environment]::NewLine)`nError ID: $errorId`nDetails: $($connectionError.Exception.ToString())"
    }
 


function Convert-Bytes {
    param(
        [long]$bytes
    )
    if ($bytes -le 0) {
        return '0 MB'
    }
    if ($bytes -ge 1GB) {
        $check = '{0:N2} GB' -f ($bytes / 1GB)
    }
    else {
        $check = '{0:N2} MB' -f ($bytes / 1MB)
    }
    return $check
}

Write-VeeamInventory
$Body = "## Check Backup Veeam VM's:`n"
$Body += "- Veeam version: $(if ($veeamVersion) { $veeamVersion } else { 'Unknown' })`n"
$Bodycopy = ""
$warn = 45
$crit = 15

##$username =  $user
#$password =  ConvertTo-SecureString   $pass -AsPlainText -Force

 
$veeamLicInfo = $null
try {
    if (-not $SureBackupOnly) {
        $veeamLicInfo = Get-VBRInstalledLicense -ErrorAction Stop
    }
}
catch {
    Write-Warning "Unable to retrieve Veeam license information: $($_.Exception.Message)"
}
$expirationDate = [datetime]::MinValue
if ($null -ne $veeamLicInfo -and [datetime]::TryParse([string]$veeamLicInfo.ExpirationDate, [ref]$expirationDate)) {
    $daysleft = ($expirationDate.Date - (Get-Date).Date).Days
    $expirationDescription = if ($veeamLicInfo.Type -eq 'Subscription') { 'License expires' } else { 'Support expires' }

    if ($daysleft -gt $warn) {
        $licenseStatus = ':white_check_mark:'
    }
    elseif ($daysleft -gt $crit) {
        $licenseStatus = ':warning:'
    }
    else {
        $licenseStatus = ':no_entry:'
    }
    $Body += "- $licenseStatus Veeam $expirationDescription in $daysleft days ($($expirationDate.ToString('yyyy-MM-dd')))`n"
}
else {
    $Body += "- :warning: UNKNOWN: Cannot get Veeam License information`n"
}
Write-VeeamReportProgress -Status 'Collecting backup jobs' -PercentComplete 0
$VbrJobs = if ($SureBackupOnly) { @() } else { Get-VBRJob }
$backupJobCount = @($VbrJobs).Count
$backupJobIndex = 0
# Same level as Check Backup Copy and SureBackup verification below.
$Body += "`n### Backup jobs`n"

foreach ($Job in $VbrJobs) { 
    $backupJobIndex++
    $backupJobProgress = if ($backupJobCount -gt 0) { [math]::Floor(60 * $backupJobIndex / $backupJobCount) } else { 60 }
    Write-VeeamReportProgress -Status "Backup jobs: $backupJobIndex of $backupJobCount - $($Job.Info.Name)" -PercentComplete $backupJobProgress

    if ($Job.JobType -eq "Backup") {


        $s = $Job.FindLastSession()
        if ($null -eq $s) {
            $Body += "`n#### $($Job.Info.Name)`nNo backup session found.`n"
            continue
        }

        $Body += "`n#### "
        $Body += $Job.Info.Name + "`n"
        $totalsuccess = 0
        $totalwarning = 0
        $totalerror = 0


        $list = $s.GetTaskSessions()
        $totalVM = $list.Count

        $vmDetails = "`n##### Details`n"
        $vmDetails += "| Name | Status  | Start time   | End time | Size | Read | Transferred | Duration |`n"
        $vmDetails += "|------|---------|--------------|----------|------|------|-------------|----------|`n"

        foreach ($vm in $list) {
            if ($vm.Status -like "*Success*") { $totalsuccess++ }
            if ($vm.Status -like "*Warning*") { $totalwarning++ }
            if ($vm.Status -like "*Error*") { $totalerror++ }
            # | Name                                      | Status  | Start time   | End time | Size         | Read       | Transferred | Duration               |
            # |-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
            # | SERVER-01.example.local                   | Success | 10:00:29     | 11:12:59 | 600 GB       | 349,8 GB   | 181 GB      | 01:12:30               |

            $vmDetails += "| $($vm.Name)| $($vm.Status)  | $('{0:HH:mm:ss}' -f $vm.Info.Progress.StartTimeLocal)   |  $('{0:HH:mm:ss}' -f $vm.Info.Progress.StopTimeLocal)| $(Convert-Bytes $vm.Info.Progress.TotalSize)        | $( Convert-Bytes $vm.Info.Progress.ReadSize)       | $(Convert-Bytes $vm.Info.Progress.TransferedSize) | $($vm.Info.Progress.Duration)  |`n"
        
        }
        $Success = "Success|" + $totalsuccess + ""
        $Warning = "Warning|" + $totalwarning + ""
        $Error_s = "Error|" + $totalerror + ""
        $TotalUsedSize = $s.Info.Progress.TotalUsedSize
        $ReadSize = $s.Info.Progress.ReadSize
        $TransferedSize = $s.Info.Progress.TransferedSize




        $TotalUsed = (Convert-Bytes $TotalUsedSize) + " |"
        $Read = (Convert-Bytes $ReadSize) + " |"
        $Transfered = (Convert-Bytes $TransferedSize) + " |"


        $duration = $s.Info.Progress.Duration
        $Body += "|" + $s.Info.CreationTime + "||||||" + $s.Info.Result + "|" + $s.Info.Progress.ProcessedObjects + " of " + $s.Info.Progress.TotalObjects + " VMs processed |`n"
        $Body += "|---|---|---|-----|---|----|----|----|`n"
        $Body += "|" + $Success + "| Start time |" + '{0:HH:mm:ss}' -f $s.Info.CreationTime + "| Total   size |" + $TotalUsed + "Backup size |" + (Convert-Bytes $s.Info.BackedUpSize) + "|`n"
        $Body += "|" + $Warning + "| End time   |" + '{0:HH:mm:ss}' -f $s.Info.EndTime + "| Data   read  |" + $Read + "Dedupe      |" + "$( [math]::Round($s.BackupStats.GetDedupeX(),2) )x" + "|`n"
        $Body += "|" + $Error_s + "| Duration     |" + $duration + "| Transferred  |" + $Transfered + "Compression |" + "$([math]::Round( $s.BackupStats.GetCompressX(),2) )x" + "|`n"
        $Body += $vmDetails
        ##| mardi 27 décembre 2022 23:30:02           |         |              |          |              |            | Success     | 1 of 1 VMs processed   |
        #|-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
        #| Success                                   | 1       | Start   time | 23:30:02 | Total   size | 10   GB    | Backup size | 28,8 MB                |
        #| Warning                                   | 0       | End   time   | 23:31:53 | Data   read  | 81   MB    | Dedupe      | 1,0x                   |
        #| Error                                     | 0       | Duration     | 00:01:51 | Transferred  | 26,6   MB  | Compression | 3,0x                   |

    }
    else {
        if ($Job.JobType -eq "SimpleBackupCopyPolicy") {
      
        }
        else {
            if ($Job.JobType -eq "EpAgentPolicy") {


                $s = $Job.FindLastSession()
                if ($null -eq $s) {
                    $Body += "`n#### $($Job.Info.Name)`nNo backup session found.`n"
                    continue
                }

                $Body += "`n#### "
                $Body += $Job.Info.Name + "`n"
                $totalsuccess = 0
                $totalwarning = 0
                $totalerror = 0


                $list = $s.GetTaskSessions()
                $totalVM = $list.Count

                $vmDetails = "`n##### Details`n"
                $vmDetails += "| Name | Status  | Start time   | End time | Size | Read | Transferred | Duration |`n"
                $vmDetails += "|------|---------|--------------|----------|------|------|-------------|----------|`n"

                foreach ($vm in $list) {
                    if ($vm.Status -like "*Success*") { $totalsuccess++ }
                    if ($vm.Status -like "*Warning*") { $totalwarning++ }
                    if ($vm.Status -like "*Error*") { $totalerror++ }
                    # | Name                                      | Status  | Start time   | End time | Size         | Read       | Transferred | Duration               |
                    # |-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
                    # | SERVER-01.example.local                   | Success | 10:00:29     | 11:12:59 | 600 GB       | 349,8 GB   | 181 GB      | 01:12:30               |

                    $vmDetails += "| $($vm.Name)| $($vm.Status)  | $('{0:HH:mm:ss}' -f $vm.Info.Progress.StartTimeLocal)   |  $('{0:HH:mm:ss}' -f $vm.Info.Progress.StopTimeLocal)| $(Convert-Bytes $vm.Info.Progress.TotalSize)        | $( Convert-Bytes $vm.Info.Progress.ReadSize)       | $(Convert-Bytes $vm.Info.Progress.TransferedSize) | $($vm.Info.Progress.Duration)  |`n"
        
                }
                $Success = "Success|" + $totalsuccess + ""
                $Warning = "Warning|" + $totalwarning + ""
                $Error_s = "Error|" + $totalerror + ""
                $TotalUsedSize = $s.Info.Progress.TotalUsedSize
                $ReadSize = $s.Info.Progress.ReadSize
                $TransferedSize = $s.Info.Progress.TransferedSize




                $TotalUsed = (Convert-Bytes $TotalUsedSize) + " |"
                $Read = (Convert-Bytes $ReadSize) + " |"
                $Transfered = (Convert-Bytes $TransferedSize) + " |"


                $duration = $s.Info.Progress.Duration
                $Body += "|" + $s.Info.CreationTime + "||||||" + $s.Info.Result + "|" + $s.Info.Progress.ProcessedObjects + " of " + $s.Info.Progress.TotalObjects + " VMs processed |`n"
                $Body += "|---|---|---|-----|---|----|----|----|`n"
                $Body += "|" + $Success + "| Start time |" + '{0:HH:mm:ss}' -f $s.Info.CreationTime + "| Total   size |" + $TotalUsed + "Backup size |" + (Convert-Bytes $s.Info.BackedUpSize) + "|`n"
                $Body += "|" + $Warning + "| End time   |" + '{0:HH:mm:ss}' -f $s.Info.EndTime + "| Data   read  |" + $Read + "Dedupe      |" + "$( [math]::Round($s.BackupStats.GetDedupeX(),2) )x" + "|`n"
                $Body += "|" + $Error_s + "| Duration     |" + $duration + "| Transferred  |" + $Transfered + "Compression |" + "$([math]::Round( $s.BackupStats.GetCompressX(),2) )x" + "|`n"
                $Body += $vmDetails
                ##| mardi 27 décembre 2022 23:30:02           |         |              |          |              |            | Success     | 1 of 1 VMs processed   |
                #|-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
                #| Success                                   | 1       | Start   time | 23:30:02 | Total   size | 10   GB    | Backup size | 28,8 MB                |
                #| Warning                                   | 0       | End   time   | 23:31:53 | Data   read  | 81   MB    | Dedupe      | 1,0x                   |
                #| Error                                     | 0       | Duration     | 00:01:51 | Transferred  | 26,6   MB  | Compression | 3,0x                   |
        
            }
            else {
                if ($Job.JobType -eq "EpAgentBackup") {
        

                    $s = $Job.FindLastSession()
                    if ($null -eq $s) {
                        $Body += "`n#### $($Job.Info.Name)`nNo backup session found.`n"
                        continue
                    }
                    $sessions = Get-VBRComputerBackupJobSession -Name "$($job.Name)" | Sort-Object –Property CreationTime –Descending | Select-Object -First 20
                    $list = @{}
                    foreach ($session in $sessions) {
                        $subtasks = Get-VBRTaskSession -Session $session
                        foreach ($subtask in $subtasks) {
                            if (!$list.ContainsKey($subtask.Name)) {
                                $list[$subtask.Name] = $subtask
                            }
                        }


                    }
                    $Body += "`n#### "
                    $Body += $Job.Info.Name + "`n"
                    $totalsuccess = 0
                    $totalwarning = 0
                    $totalerror = 0
  
   
                    $totalVM = $list.Count
  
                    $vmDetails = "`n##### Details`n"
                    $vmDetails += "| Name | Status  | Start time   | End time | Size | Read | Transferred | Duration |`n"
                    $vmDetails += "|------|---------|--------------|----------|------|------|-------------|----------|`n"
  
                    foreach ($vmkey in $list.GetEnumerator()) {
                        $vm = $vmkey.value
                        if ($vm.Status -like "*Success*") { $totalsuccess++ }
                        if ($vm.Status -like "*Warning*") { $totalwarning++ }
                        if ($vm.Status -like "*Error*") { $totalerror++ }
                        # | Name                                      | Status  | Start time   | End time | Size         | Read       | Transferred | Duration               |
                        # |-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
                        # | SERVER-01.example.local                   | Success | 10:00:29     | 11:12:59 | 600 GB       | 349,8 GB   | 181 GB      | 01:12:30               |
  
                        $vmDetails += "| $($vm.Name)| $($vm.Status)  | $('{0:HH:mm:ss}' -f $vm.Info.Progress.StartTimeLocal)   |  $('{0:HH:mm:ss}' -f $vm.Info.Progress.StopTimeLocal)| $(Convert-Bytes $vm.Info.Progress.TotalSize)        | $( Convert-Bytes $vm.Info.Progress.ReadSize)       | $(Convert-Bytes $vm.Info.Progress.TransferedSize) | $($vm.Info.Progress.Duration)  |`n"
          
                    }
                    $Success = "Success|" + $totalsuccess + ""
                    $Warning = "Warning|" + $totalwarning + ""
                    $Error_s = "Error|" + $totalerror + ""
                    $TotalUsedSize = $s.Info.Progress.TotalUsedSize
                    $ReadSize = $s.Info.Progress.ReadSize
                    $TransferedSize = $s.Info.Progress.TransferedSize
  
  
  
  
                    $TotalUsed = (Convert-Bytes $TotalUsedSize) + " |"
                    $Read = (Convert-Bytes $ReadSize) + " |"
                    $Transfered = (Convert-Bytes $TransferedSize) + " |"
  
  
                    $duration = $s.Info.Progress.Duration
                    $Body += "|" + $s.Info.CreationTime + "||||||" + $s.Info.Result + "|" + $s.Info.Progress.ProcessedObjects + " of " + $s.Info.Progress.TotalObjects + " VMs processed |`n"
                    $Body += "|---|---|---|-----|---|----|----|----|`n"
                    $Body += "|" + $Success + "| Start time |" + '{0:HH:mm:ss}' -f $s.Info.CreationTime + "| Total   size |" + $TotalUsed + "Backup size |" + (Convert-Bytes $s.Info.BackedUpSize) + "|`n"
                    $Body += "|" + $Warning + "| End time   |" + '{0:HH:mm:ss}' -f $s.Info.EndTime + "| Data   read  |" + $Read + "Dedupe      |" + "$( [math]::Round($s.BackupStats.GetDedupeX(),2) )x" + "|`n"
                    $Body += "|" + $Error_s + "| Duration     |" + $duration + "| Transferred  |" + $Transfered + "Compression |" + "$([math]::Round( $s.BackupStats.GetCompressX(),2) )x" + "|`n"
                    $Body += $vmDetails
                    ##| mardi 27 décembre 2022 23:30:02           |         |              |          |              |            | Success     | 1 of 1 VMs processed   |
                    #|-------------------------------------------|---------|--------------|----------|--------------|------------|-------------|------------------------|
                    #| Success                                   | 1       | Start   time | 23:30:02 | Total   size | 10   GB    | Backup size | 28,8 MB                |
                    #| Warning                                   | 0       | End   time   | 23:31:53 | Data   read  | 81   MB    | Dedupe      | 1,0x                   |
                    #| Error                                     | 0       | Duration     | 00:01:51 | Transferred  | 26,6   MB  | Compression | 3,0x                   |
          
                }
                else {
                    Write-Verbose "Skipping unsupported Veeam job type '$($Job.JobType)' for job '$($Job.Name)'."
                }      
            }
        }
    }


}
Write-VeeamReportProgress -Status 'Collecting Backup Copy jobs' -PercentComplete 60

 
$list = @()
$backupCopyJobs = if ($SureBackupOnly) { @() } else { @(Get-VBRBackupCopyJob) }
$backupCopyJobCount = $backupCopyJobs.Count
$backupCopyJobIndex = 0
$Bodycopy += "`n### Check Backup Copy`n"
if ($backupCopyJobs.Count -eq 0) {
    $Bodycopy += "No Backup Copy jobs are configured.`n"
}
#$ListSession = [Veeam.Backup.Core.CBackupSession]::GetAll() | Sort-Object -Property EndTime
             
foreach ($BJob in $backupCopyJobs) {
    $backupCopyJobIndex++
    $backupCopyProgress = 60 + [math]::Floor(25 * $backupCopyJobIndex / $backupCopyJobCount)
    Write-VeeamReportProgress -Status "Backup Copy jobs: $backupCopyJobIndex of $backupCopyJobCount - $($BJob.Name)" -PercentComplete $backupCopyProgress

    $lastRestorepoint = @{}
    $proccessRestorePointID = @()
    $lastSession = Get-VBRSession -Job $BJob | Sort-Object CreationTime -Descending | Select-Object -First 1
    
    foreach ($BcJob in (($BJob.TargetRepository.GetBackups()) | Sort-Object –Property CreationTime –Descending)) {
        foreach ($RP in (Get-VBRRestorePoint -Backup $BcJob  | Sort-Object –Property EndTime –Descending) ) {
            #  | Where-Object -Property DisplayName -Like "<job name>"   $dp
            
            if ( !$lastRestorepoint.ContainsKey($RP.DisplayName)) {
                $lastRestorepoint[$RP.DisplayName] = @{}
                $lastRestorepoint[$RP.DisplayName]['count'] = 0
                $lastRestorepoint[$RP.DisplayName]['LastRP'] = $null
            } 
            if (!($proccessRestorePointID -contains $RP.Id.Guid)) { 
                $lastRestorepoint[$RP.DisplayName]['count'] = $lastRestorepoint[$RP.DisplayName]['count'] + 1
                if ($null -eq $lastRestorepoint[$RP.DisplayName]['LastRP'] -or $RP.CreationTime -gt $lastRestorepoint[$RP.DisplayName]['LastRP'].CreationTime) {
                    $lastRestorepoint[$RP.DisplayName]['LastRP'] = $RP
                }
                $proccessRestorePointID += $RP.Id.Guid 
            }
        } 
    } 
    $BCBackup = Get-VBRBackup -name  $BJob.name 
    $Session = if ($null -ne $lastSession) {
        Get-VBRBackupSession -Id $lastSession.Id
    }
    else {
        $null
    }

    $vmDetails = "`n##### Details`n"
    $vmDetails += "| Name | Last Copy   | copy health | Number of RP |`n"
    $vmDetails += "|------|---------|---------|---------|`n"
  
    foreach ($vmkey in $lastRestorepoint.GetEnumerator() | Sort-Object –Property name) {
        $vm = $vmkey.value['LastRP']
        if ($null -eq $vm) {
            continue
        }
        if ($vm.HealthStatus -eq "Ok") {
            $VmStatusCopy = ":white_check_mark: OK"
        }
        else {
            $VmStatusCopy = ":x: $($vm.HealthStatus)"
        }
        $vmDetails += "| $($vm.DisplayName) | $($vm.CreationTime) | $($VmStatusCopy)  | $($vmkey.value['Count']) |`n"
    }

    $Bodycopy += "`n"
    $Bodycopy += "#### " + $bJob.Name + "`n"
    if ($bJob.LastState -eq "Stopped" -and $null -ne $Session) {
        if ($Session.Result -eq "Success") { $status = ":white_check_mark:" }else { $status = ":x:" }
        $Bodycopy += "| Result |  |`n"
        $Bodycopy += "|----|----|`n"
        $Bodycopy += "| Status |  $($Session.Result) $status |`n"
        $Bodycopy += "| Start | $($Session.CreationTime) |`n"
        $Bodycopy += "| End |  $($Session.EndTime) |`n"
        $Bodycopy += "| Duration |  $($Session.Progress.Duration) |`n"
        if ($Session.BackupStats.BackupSize -gt 0) { $Bodycopy += "| Processed |  $( Convert-Bytes($Session.BackupStats.BackupSize)) |`n" }
        if ($Session.BackupStats.DataSize -gt 0) { $Bodycopy += "| Read |  $( Convert-Bytes($Session.BackupStats.DataSize)) |`n" }
        $Bodycopy += "| VM count |  $($BCBackup.VmCount) |`n"
    }
    elseif ($null -eq $Session) {
        $Bodycopy += "$($bJob.Name) has no backup session available :warning:`n"
    }
    else {
        $Bodycopy += "$($bJob.Name) is $($bJob.LastState) :exclamation: `n"
    }
    $Bodycopy += $vmDetails
}

Write-VeeamReportProgress -Status 'Collecting SureBackup jobs' -PercentComplete 85

$BodySureBackup = "`n### SureBackup verification`n"
$sureBackupCommands = @(
    'Get-VBRSureBackupJob',
    'Get-VBRSureBackupSession',
    'Get-VBRSureBackupTaskSession'
)
$missingSureBackupCommands = @($sureBackupCommands | Where-Object {
    -not (Get-Command -Name $_ -ErrorAction SilentlyContinue)
})
if ($missingSureBackupCommands.Count -gt 0) {
    $BodySureBackup += "SureBackup reporting is unavailable. Missing Veeam cmdlets: $($missingSureBackupCommands -join ', ').`n"
}
else {
    try {
        $sureBackupJobs = @(Get-VBRSureBackupJob -ErrorAction Stop)
        if ($sureBackupJobs.Count -eq 0) {
            $BodySureBackup += "No SureBackup jobs are configured.`n"
        }
        else {
            $sureBackupJobCount = $sureBackupJobs.Count
            $sureBackupJobIndex = 0
            foreach ($sureBackupJob in $sureBackupJobs | Sort-Object -Property Name) {
                $sureBackupJobIndex++
                $sureBackupProgress = 85 + [math]::Floor(15 * $sureBackupJobIndex / $sureBackupJobCount)
                Write-VeeamReportProgress -Status "SureBackup jobs: $sureBackupJobIndex of $sureBackupJobCount - $($sureBackupJob.Name)" -PercentComplete $sureBackupProgress

                $BodySureBackup += "`n#### $($sureBackupJob.Name)`n"
                $virtualLab = if ($sureBackupJob.VirtualLab.Name) { $sureBackupJob.VirtualLab.Name } elseif ($sureBackupJob.VirtualLab) { $sureBackupJob.VirtualLab } else { 'Not configured' }
                $applicationGroup = if ($sureBackupJob.ApplicationGroup.Name) { $sureBackupJob.ApplicationGroup.Name } elseif ($sureBackupJob.ApplicationGroup) { $sureBackupJob.ApplicationGroup } else { 'Not configured' }
                $linkedJobs = @($sureBackupJob.LinkedJob | ForEach-Object {
                    if ($_.Name) { $_.Name } elseif ($_.Info.Name) { $_.Info.Name } else { [string]$_ }
                }) -join ', '
                if ([string]::IsNullOrWhiteSpace($linkedJobs)) {
                    $linkedJobs = 'None'
                }
                $BodySureBackup += "| Configuration | Value |`n"
                $BodySureBackup += "|---|---|`n"
                $BodySureBackup += "| Enabled / scheduled | $($sureBackupJob.IsEnabled) / $($sureBackupJob.ScheduleEnabled) |`n"
                $BodySureBackup += "| Virtual lab | $virtualLab |`n"
                $BodySureBackup += "| Application group | $applicationGroup |`n"
                $BodySureBackup += "| Linked jobs | $linkedJobs |`n"

                try {
                    $sureBackupSessions = @(Get-VBRSureBackupSession -Name $sureBackupJob.Name -ErrorAction Stop |
                        Sort-Object -Property CreationTime -Descending)
                    $sureBackupSession = $sureBackupSessions | Select-Object -First 1
                    if ($null -eq $sureBackupSession) {
                        $BodySureBackup += "No SureBackup session found. Last configured status: $($sureBackupJob.LastResult) ($($sureBackupJob.LastState)).`n"
                        continue
                    }

                    $sessionResult = if ($sureBackupSession.Result) { $sureBackupSession.Result } else { $sureBackupJob.LastResult }
                    $sessionState = if ($sureBackupSession.State) { $sureBackupSession.State } else { $sureBackupJob.LastState }
                    $sessionStart = if ($sureBackupSession.CreationTime) { $sureBackupSession.CreationTime } elseif ($sureBackupSession.StartTime) { $sureBackupSession.StartTime } else { $sureBackupJob.LastRun }
                    $sessionEnd = if ($sureBackupSession.EndTime) { $sureBackupSession.EndTime } else { 'In progress or unavailable' }
                    $sessionDuration = $null
                    if ($sureBackupSession.Progress.Duration) {
                        $sessionDuration = $sureBackupSession.Progress.Duration
                    }
                    elseif ($sureBackupSession.Info.Progress.Duration) {
                        $sessionDuration = $sureBackupSession.Info.Progress.Duration
                    }
                    elseif ($sessionStart -is [datetime] -and $sureBackupSession.EndTime -is [datetime]) {
                        $sessionDuration = $sureBackupSession.EndTime - $sessionStart
                    }
                    if ($null -eq $sessionDuration) {
                        $sessionDuration = 'Unavailable'
                    }

                    $sureBackupTasks = @(Get-VBRSureBackupTaskSession -Session $sureBackupSession -ErrorAction Stop)
                    $successfulTasks = 0
                    $failedTasks = 0
                    $warningTasks = 0
                    $skippedTasks = 0
                    $otherTasks = 0
                    $taskRows = foreach ($sureBackupTask in $sureBackupTasks) {
                        $taskStatus = if ($sureBackupTask.Status) { [string]$sureBackupTask.Status } elseif ($sureBackupTask.Result) { [string]$sureBackupTask.Result } elseif ($sureBackupTask.State) { [string]$sureBackupTask.State } else { 'Unknown' }
                        if ($taskStatus -match '(?i)success|succeeded') {
                            $successfulTasks++
                        }
                        elseif ($taskStatus -match '(?i)warning') {
                            $warningTasks++
                        }
                        elseif ($taskStatus -match '(?i)failed|error|cancelled|canceled') {
                            $failedTasks++
                        }
                        elseif ($taskStatus -match '(?i)skip') {
                            $skippedTasks++
                        }
                        else {
                            $otherTasks++
                        }

                        "| $($sureBackupTask.Name) | $taskStatus |"
                    }
                    $processedTasks = $successfulTasks + $failedTasks + $warningTasks
                    if ($sureBackupTasks.Count -gt 0) {
                        $BodySureBackup += "`n| Last run | Result | State | Duration |`n"
                        $BodySureBackup += "|---|---|---|---|`n"
                        $BodySureBackup += "| $sessionStart | $sessionResult | $sessionState | $sessionDuration |`n"
                        $BodySureBackup += "`n| Task summary | Count |`n"
                        $BodySureBackup += "|---|---:|`n"
                        $BodySureBackup += "| Total tasks | $($sureBackupTasks.Count) |`n"
                        $BodySureBackup += "| Processed tasks | $processedTasks |`n"
                        $BodySureBackup += "| Successful tasks | $successfulTasks |`n"
                        $BodySureBackup += "| Failed tasks | $failedTasks |`n"
                        $BodySureBackup += "| Warning tasks | $warningTasks |`n"
                        $BodySureBackup += "| Skipped tasks | $skippedTasks |`n"
                        if ($otherTasks -gt 0) {
                            $BodySureBackup += "| Other or unclassified tasks | $otherTasks |`n"
                        }

                        $BodySureBackup += "`n##### VM verification details`n"
                        $BodySureBackup += "| VM | Status |`n"
                        $BodySureBackup += "|---|---|`n"
                        foreach ($taskRow in $taskRows) {
                            $BodySureBackup += "$taskRow`n"
                        }
                    }
                    else {
                        $BodySureBackup += "`n| Last run | Result | State | Duration |`n"
                        $BodySureBackup += "|---|---|---|---|`n"
                        $BodySureBackup += "| $sessionStart | $sessionResult | $sessionState | $sessionDuration |`n"
                        $BodySureBackup += "`nNo VM verification task details were returned for this session.`n"
                    }
                }
                catch {
                    $BodySureBackup += "Collection failed for this SureBackup job: $($_.Exception.Message)`n"
                }
            }
        }
    }
    catch {
        $BodySureBackup += "Unable to retrieve SureBackup jobs: $($_.Exception.Message)`n"
    }
}

Write-VeeamReportProgress -Status 'Finishing report' -PercentComplete 100
if ($SureBackupOnly) {
    $Body = $BodySureBackup
}
else {
    $Body += $Bodycopy
    $Body += $BodySureBackup
}
if (-not [string]::IsNullOrWhiteSpace($OutputPath)) {
    $outputDirectory = Split-Path -Path $OutputPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -Path $outputDirectory -ItemType Directory -Force -ErrorAction Stop | Out-Null
    }
    $Body | Out-File -LiteralPath $OutputPath -Encoding UTF8 -ErrorAction Stop
    if (-not $NoOpen) {
        Start-Process -FilePath 'notepad.exe' -ArgumentList "`"$OutputPath`"" -ErrorAction Stop
    }
}
$Body
}
finally {
    Write-Progress -Id 10 -Activity $progressActivity -Completed
    if ($script:VbrConnected) {
        try {
            Disconnect-VBRServer -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Warning "Unable to disconnect from Veeam server '$Server': $($_.Exception.Message)"
        }
    }
}
